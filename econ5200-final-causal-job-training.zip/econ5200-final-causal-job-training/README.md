# ECON 5200 Final Project: Causal Effect of Job Training on Earnings

## Project Overview

This project estimates the causal effect of job training participation on post-program earnings using the Lalonde / Dehejia-Wahba job training data.

## Causal Question

Does participation in the National Supported Work job-training program cause an increase in later earnings?

## Treatment

Participation in job training (`treat`).

## Outcome

Real earnings in 1978 (`re78`).

## Identification Strategy

Double Machine Learning using pre-treatment covariates.

## Key Assumption

Conditional independence: after controlling for observed pre-treatment characteristics, treatment assignment is as good as random.

## Why Prediction Alone Is Insufficient

A prediction model can estimate who is likely to earn more, but it cannot isolate whether the training program itself caused the earnings change. A causal method is needed because the policy question is counterfactual.

## Main Result

The main DML estimate is approximately $1,173, with a 95% confidence interval from $-209 to $2,556.

## Repository Structure

- `app.py`: Streamlit dashboard
- `data/processed`: cleaned data
- `outputs/figures`: figures
- `outputs/tables`: result tables
- `reports`: written deliverables
